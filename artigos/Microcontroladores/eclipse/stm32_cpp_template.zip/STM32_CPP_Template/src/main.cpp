/*
 * main.c
 *
 *      Author: Ronan Alves da Paixão
 *              <ronan@dapaixao.com.br>
 *              http://ronan.dapaixao.com.br
 */

#include <stdint.h>
#include "stm32f10x_conf.h"
#include "led.h"


LED led1(GPIOC, GPIO_Pin_13);

int main(void)
{
  volatile uint32_t wait;
  while (1)
  {
      led1.toggle();
	  wait = 300000; // ~10Hz @ 72MHz @ -O2
	  while(--wait);
  }

  return 0;
}
