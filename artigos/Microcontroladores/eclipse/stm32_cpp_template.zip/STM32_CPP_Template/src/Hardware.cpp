/*
 * Hardware.cpp
 *
 *  Created on: 08/09/2011
 *      Author: Ronan
 */

#include "Hardware.h"
#include "stm32f10x_conf.h"

void Hardware::pin_config(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, GPIOMode_TypeDef GPIO_Mode, uint32_t GPIO_Remap)
{
    uint32_t GPIO_clock;
    if (GPIO_Remap) {
        GPIO_PinRemapConfig(GPIO_Remap, ENABLE);
    }

    if (GPIOx==GPIOA)
        GPIO_clock = RCC_APB2Periph_GPIOA;
    else if (GPIOx==GPIOB)
        GPIO_clock = RCC_APB2Periph_GPIOB;
    else if (GPIOx==GPIOC)
        GPIO_clock = RCC_APB2Periph_GPIOC;
    else if (GPIOx==GPIOD)
        GPIO_clock = RCC_APB2Periph_GPIOD;
    else if (GPIOx==GPIOE)
        GPIO_clock = RCC_APB2Periph_GPIOE;
    else if (GPIOx==GPIOF)
        GPIO_clock = RCC_APB2Periph_GPIOF;
    else if (GPIOx==GPIOG)
        GPIO_clock = RCC_APB2Periph_GPIOG;
    else
        while (1);

    RCC_APB2PeriphClockCmd(GPIO_clock, ENABLE);

    GPIO_InitTypeDef GPIO_InitStructure;

    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode;
    GPIO_Init(GPIOx, &GPIO_InitStructure);
}
