/*
 * Hardware.h
 *
 *      Author: Ronan Alves da Paixão
 *              <ronan@dapaixao.com.br>
 *              http://ronan.dapaixao.com.br
 */

#ifndef HARDWARE_H_
#define HARDWARE_H_

#include <stm32f10x.h>
#include <stm32f10x_gpio.h>

class Hardware
{
public:
    void lock();
    void unlock();

protected:
    void pin_config(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, GPIOMode_TypeDef GPIO_Mode, uint32_t GPIO_Remap=0);
};

#endif /* HARDWARE_H_ */
