/*
 * LED.h
 *
 *      Author: Ronan Alves da Paixão
 *              <ronan@dapaixao.com.br>
 *              http://ronan.dapaixao.com.br
 */

#ifndef LED_H_
#define LED_H_

#include "Hardware.h"

class LED: public Hardware
{
public:
    LED(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
    inline void on()     { led_port->BSRR = led_pin; }
    inline void off()    { led_port->BRR  = led_pin; }
    inline void toggle() { led_port->ODR ^= led_pin; }

private:
    GPIO_TypeDef* led_port;
    uint16_t led_pin;
};

inline LED::LED(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin) :
    led_port(GPIOx),
    led_pin(GPIO_Pin)
{
    pin_config(led_port, led_pin, GPIO_Mode_Out_PP);
}

#endif /* LED_H_ */
